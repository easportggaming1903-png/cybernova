import fs from 'fs'
import path from 'path'
import matter from 'gray-matter'
import Layout from '../../components/Layout'
import Link from 'next/link'

export default function Post({content, data}){
  return (
    <Layout>
      <article className="prose prose-invert max-w-none">
        <h1>{data.title}</h1>
        <p className="text-sm text-gray-400">{data.date}</p>
        <div dangerouslySetInnerHTML={{__html: content}} />
        <p className="mt-6"><Link href="/"><a>Back</a></Link></p>
      </article>
    </Layout>
  )
}

export async function getStaticPaths(){
  const en = path.join(process.cwd(),'content','en')
  const tr = path.join(process.cwd(),'content','tr')
  const files = [...fs.readdirSync(en).filter(f=>f.endsWith('.md')), ...fs.readdirSync(tr).filter(f=>f.endsWith('.md'))]
  return {paths: files.map(f=>({params:{slug:f.replace('.md','')}})), fallback:false}
}

export async function getStaticProps({params}){
  const slug = params.slug
  const tryPath = (p)=>{ try { return fs.readFileSync(p,'utf-8')} catch(e){return null} }
  const enPath = path.join(process.cwd(),'content','en', slug + '.md')
  const trPath = path.join(process.cwd(),'content','tr', slug + '.md')
  const file = tryPath(enPath) || tryPath(trPath)
  const fm = matter(file)
  const remark = require('remark')
  const html = (await remark().use(require('remark-html')).process(fm.content)).toString()
  return {props:{content:html, data:fm.data}}
}
