import Layout from '../components/Layout'
export default function Contact(){return (<Layout><h1>Contact</h1><p>Send us an email: hello@cybernova.example</p></Layout>)}
