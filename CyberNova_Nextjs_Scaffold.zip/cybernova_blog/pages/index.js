import Link from 'next/link'
import Layout from '../components/Layout'
import fs from 'fs'
import matter from 'gray-matter'

export default function Home({postsEn, postsTr}){
  return (
    <Layout>
      <section className="mb-8">
        <div className="p-6 rounded-lg" style={{background:'linear-gradient(135deg, rgba(124,58,237,0.12), rgba(6,182,212,0.06))'}}>
          <h1 className="text-3xl font-bold">CyberNova</h1>
          <p className="mt-2 text-gray-300">Next-gen technology blog. Türkçe & English.</p>
        </div>
      </section>

      <section className="grid md:grid-cols-2 gap-6">
        <div>
          <h2 className="text-xl font-semibold mb-3">Latest (EN)</h2>
          {postsEn.map(p=>(
            <article key={p.slug} className="p-4 bg-[#071021] rounded-lg mb-3">
              <Link href={`/posts/${p.slug}`}><a className="font-semibold">{p.data.title}</a></Link>
              <div className="text-sm text-gray-400 mt-1">{p.data.description}</div>
            </article>
          ))}
        </div>
        <div>
          <h2 className="text-xl font-semibold mb-3">Son Yazılar (TR)</h2>
          {postsTr.map(p=>(
            <article key={p.slug} className="p-4 bg-[#071021] rounded-lg mb-3">
              <Link href={`/posts/${p.slug}`}><a className="font-semibold">{p.data.title}</a></Link>
              <div className="text-sm text-gray-400 mt-1">{p.data.description}</div>
            </article>
          ))}
        </div>
      </section>
    </Layout>
  )
}

export async function getStaticProps(){
  const fm = require('gray-matter')
  const path = require('path')
  const fs = require('fs')
  const postsEnDir = path.join(process.cwd(), 'content', 'en')
  const postsTrDir = path.join(process.cwd(), 'content', 'tr')
  const readPosts = (dir)=>{
    const files = fs.readdirSync(dir)
    return files.filter(f=>f.endsWith('.md')).map(file=>{
      const text = fs.readFileSync(path.join(dir,file),'utf-8')
      const data = fm(text)
      return {slug: file.replace('.md',''), data: data.data}
    })
  }
  const postsEn = readPosts(postsEnDir)
  const postsTr = readPosts(postsTrDir)
  return {props:{postsEn, postsTr}}
}
