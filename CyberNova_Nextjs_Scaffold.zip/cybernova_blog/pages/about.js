import Layout from '../components/Layout'
export default function About(){return (<Layout><h1>About CyberNova</h1><p>CyberNova is a next-gen technology blog covering AI, hardware, and future tech.</p></Layout>)}
