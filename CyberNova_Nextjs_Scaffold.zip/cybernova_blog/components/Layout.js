import Link from 'next/link'

export default function Layout({children}){
  const year = new Date().getFullYear()
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#020617] via-[#081022] to-[#071021] text-gray-100">
      <header className="max-w-4xl mx-auto p-6 flex items-center justify-between">
        <Link href="/"><a className="text-2xl font-bold tracking-wide">CyberNova</a></Link>
        <nav className="space-x-4">
          <Link href="/"><a className="text-sm">Home</a></Link>
          <Link href="/about"><a className="text-sm">About</a></Link>
          <Link href="/contact"><a className="text-sm">Contact</a></Link>
        </nav>
      </header>
      <main className="max-w-4xl mx-auto p-6">{children}</main>
      <footer className="max-w-4xl mx-auto p-6 text-sm opacity-80">© {year} CyberNova — Future of Tech</footer>
    </div>
  )
}
