Vercel deploy: push to GitHub and import repo; build: npm run build
