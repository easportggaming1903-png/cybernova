CyberNova - Next.js + Tailwind bilingual blog

Quick start:

1) unzip
2) npm install
3) npm install gray-matter remark remark-html
4) npm run dev

Notes: Deploy on Vercel for easiest workflow.
