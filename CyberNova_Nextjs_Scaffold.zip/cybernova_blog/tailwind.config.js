module.exports = {
  content: ['./pages/**/*.{js,jsx}', './components/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        cyberbg: '#0b1020',
        cyberaccent: '#7c3aed'
      }
    },
  },
  plugins: [],
}
